INSERT INTO books (
book_name,
author,
editor,
translator,
compiler,
publisher,
edition,
language_id,
length_pages,
cover,
fiction,
genre_id,
dewey_decimal,
pub_year) VALUES
	('VHS'),
	('DVD'),
	('BluRay'),
	('.mp4');